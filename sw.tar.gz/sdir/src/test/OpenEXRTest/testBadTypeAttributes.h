//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Weta Digital, Ltd and Contributors to the OpenEXR Project.
//

#ifndef TEST_BAD_TYPE_ATTRIBUTES
#define TEST_BAD_TYPE_ATTRIBUTES

#include <string>

void testBadTypeAttributes (const std::string & tempDir);

#endif
